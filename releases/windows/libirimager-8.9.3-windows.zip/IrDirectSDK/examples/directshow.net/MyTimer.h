#pragma once
ref class MyTimer :
public System::Timers::Timer
{
public:	
	System::Object ^ passingRef;	
};

