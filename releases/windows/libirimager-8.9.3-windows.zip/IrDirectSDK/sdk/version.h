#include <string>

static std::string libirimager_version_string = "8.9.3";
static std::string libirimager_commit_string  = "a8fa0438"; 
static std::string libirimager_commit_branch  = "Release_8.9.3"; 
static std::string libirimager_commit_date    = "Thu Jan 16 11:08:27 2025";
