﻿===================================================================================
===================
 IR Imager Direct SDK example applications 
=====================
===================================================================================
Open the solution file vs<VERSION>_libirimagerExamples.sln. There, you can compile

the Debug or Release applications. The applications can directly be executed via
the Debugger or by executing them by hand as follows:

cd Release\Win32\
set PATH=%PATH%;..\..\sdk\Win32

irimagerShow.exe ..\..\generic.xml

 or

cd x64\Release

set PATH=%PATH%;
..\..\sdk\x64
irimagerShow.exe ..\..\generic.xml

respectively.




For further informations, please find the SDK's documentation at www.evocortex.com.